package android.demo.entries;

import java.io.Serializable;

/**
 * Created by Drakulla on 8/27/2018.
 */

public class TeacherAccount implements Serializable{
    private int id;
    private String name;
    private String gender;
    private String qualification;
    private String interested_subject;
    private String interested_classes;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getInterested_subject() {
        return interested_subject;
    }

    public void setInterested_subject(String interested_subject) {
        this.interested_subject = interested_subject;
    }

    public String getInterested_classes() {
        return interested_classes;
    }

    public void setInterested_classes(String interested_classes) {
        this.interested_classes = interested_classes;
    }
}

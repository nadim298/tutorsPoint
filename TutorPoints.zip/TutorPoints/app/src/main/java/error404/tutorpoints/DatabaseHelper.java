
package error404.tutorpoints;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.demo.entries.TeacherAccount;

import static android.R.attr.version;


public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "teacherAccount";
    public static final String COL_1 = "email";
    public static final String COL_2 = "password";
    public static final String COL_3 = "name";
    public static final String COL_4 = "gender";
    public static final String COL_5 = "qualification";
    public static final String COL_6 = "interested_subject";
    public static final String COL_7 = "interested_class";
    public static final String COL_8 = "phone_no";



    public DatabaseHelper(Context context) {


        super(context,"dbAccount", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("Create table teacherAccount(email text primary key,password text,name text,gender text,qualification text,interested_subject text,interested_class text,phone_no text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists teacherAccount");
    }
    public boolean insert(String email,String password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("email",email);
        contentValues.put("password",password);
        long ins=db.insert("teacherAccount",null,contentValues);

        if(ins==-1) return false;
        else return true;
    }
    public Boolean isEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from teacherAccount where email=?",new String[]{email});

        if (cursor.getCount()>0 ) {
            //if cursor has value then in user database there is user associated with this given email so return true
            return false;
        }

        //if email does not exist return false
        return true;
    }
    public Boolean isEmailAndPasswordMatch(String email,String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from teacherAccount where email=? and password=?",new String[]{email,password});

        if(cursor.getCount()>0) return true;
        else return false;
    }

    /*Update*/
    public boolean updateData(String email,String name,String gender,String qualification,String interested_subject,String interested_class,String phone_no) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_3,name);
        contentValues.put(COL_4,gender);
        contentValues.put(COL_5,qualification);
        contentValues.put(COL_6,interested_subject);
        contentValues.put(COL_7,interested_class);
        contentValues.put(COL_8,phone_no);
        db.update(TABLE_NAME, contentValues, "email = ?",new String[] { email });
        return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    public TeacherAccount getData(String emailText) {
        String query = "Select * FROM " + TABLE_NAME + " WHERE " + COL_1 + " =  \"" + emailText + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        TeacherAccount account = new TeacherAccount();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            account.setName(cursor.getString(2));
        } else {
            account = null;
        }
        return account;
    }
}


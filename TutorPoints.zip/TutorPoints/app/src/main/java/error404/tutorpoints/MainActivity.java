package error404.tutorpoints;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button tutor_btn,tution_btn;
    Toolbar toolbar;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar= (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        db=new DatabaseHelper(this);

        tutor_btn= (Button) findViewById(R.id.tutorBtn);
        tution_btn= (Button) findViewById(R.id.tutionBtn);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.sign_in_as_teacher:
                Intent sign_in_as_teacher_page=new Intent(this,SignInAsTeacher.class);
                startActivity(sign_in_as_teacher_page);
                break;
            case R.id.sign_up_as_teacher:
                Intent sign_up_as_teacher_page=new Intent(this,SignUpAsTeacher.class);
                startActivity(sign_up_as_teacher_page);
                break;

            case R.id.about_us:
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }

    public void tutors(View view) {
        viewAll();
    }

    public void tutions(View view) {
        Intent tution=new Intent(this,Tution.class);
        startActivity(tution);
    }

    public void viewAll() {

                        Cursor res = db.getAllData();
                        if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Name :"+ res.getString(2)+"\n");
                            buffer.append("Gender :"+ res.getString(3)+"\n");
                            buffer.append("Qualification :"+ res.getString(4)+"\n");
                            buffer.append("Interested subject to teach:"+ res.getString(5)+"\n");
                            buffer.append("Interested class to teach :"+ res.getString(6)+"\n");
                            buffer.append("Phone No :"+ res.getString(7)+"\n\n");


                        }

                        // Show all data
                        showMessage("Tutors",buffer.toString());


    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void home(View view) {

    }
    public void onBackPressed() {

    }
}

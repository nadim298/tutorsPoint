package error404.tutorpoints;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper2 extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "dbAccountTution";
    public static final String TABLE_NAME = "tutionDetails";
    public static final String COL_1 = "id";
    public static final String COL_2 = "name";
    public static final String COL_3 = "phone_no";
    public static final String COL_4 = "class";
    public static final String COL_5 = "subject";
    public static final String COL_6 = "location";
    public static final String COL_7 = "password";

    public DatabaseHelper2(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table tutionDetails (id INTEGER PRIMARY KEY AUTOINCREMENT,name text,phone_no INTEGER,class text,subject text,location text,password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists tutionDetails");
        onCreate(db);
    }

    public Boolean insertData(String name,String phone_no,String classes,String subject,String location,String password) {
        int ph=0;

        try {
            ph = Integer.parseInt(phone_no);
        } catch(NumberFormatException nfe) {
            // Handle parse error.
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,name);
        contentValues.put(COL_3,ph);
        contentValues.put(COL_4,classes);
        contentValues.put(COL_5,subject);
        contentValues.put(COL_6,location);
        contentValues.put(COL_7,password);
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    public boolean updateData(String id,String name,String phone_no,String classes,String subject,String location,String password) {
        int ph=0;


        try {
            ph = Integer.parseInt(phone_no);

        } catch(NumberFormatException nfe) {
            // Handle parse error.
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,name);
        contentValues.put(COL_3,ph);
        contentValues.put(COL_4,classes);
        contentValues.put(COL_5,subject);
        contentValues.put(COL_6,location);
        contentValues.put(COL_7,password);
        db.update(TABLE_NAME, contentValues, "id = ?",new String[] { id });
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "id = ?",new String[] {id});
    }

    public Boolean isIDAndPasswordMatch(String id,String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+TABLE_NAME+" where id=? and password=?",new String[]{id,password});

        if(cursor.getCount()>0) return true;
        else return false;
    }


}


package error404.tutorpoints;

import android.content.Intent;
import android.database.Cursor;
import android.demo.entries.TeacherAccount;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileTeacher extends AppCompatActivity {
    String emailText;
    DatabaseHelper db;
    TextView email,name,qualification,interested_subject,interested_classes,phone_no;
    Button editProfileBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_teacher);


        email= (TextView) findViewById(R.id.email);
        name= (TextView) findViewById(R.id.nameET);
        qualification= (EditText) findViewById(R.id.qualificationET);
        interested_subject= (EditText) findViewById(R.id.interested_subjectET);
        phone_no= (EditText) findViewById(R.id.phone_noET);
        interested_classes= (TextView) findViewById(R.id.interestedClass);

        db=new DatabaseHelper(this);

        editProfileBtn= (Button) findViewById(R.id.edit_profile);




        Bundle b =getIntent().getExtras();

        if(b!=null)
        {
            String emailText =b.getString("email");
            email.setText(emailText);

        }
        //displayDetails();


        editProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent edit_profile_page=new Intent(ProfileTeacher.this,EditProfile.class);
                edit_profile_page.putExtra("email",email.getText());
                startActivity(edit_profile_page);
            }
        });

    }

    public void logout(View view) {
        Intent home_page=new Intent(ProfileTeacher.this,MainActivity.class);

        startActivity(home_page);
    }


    public void displayDetails() {

        TeacherAccount account = db.getData(emailText);
        name.setText(account.getName());


    }

    public void onBackPressed() {

    }

}

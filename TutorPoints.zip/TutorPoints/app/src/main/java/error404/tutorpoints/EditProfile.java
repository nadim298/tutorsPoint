package error404.tutorpoints;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class EditProfile extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    ArrayList<String>chocieCollection;
    String emailText,classCollection;
    CheckBox chk1,chk2,chk3,chk4,chk5,chk6,chk7,chk8,chk9,chk10;
    DatabaseHelper db;
    TextView email,addClasses;
    EditText name,qualification,interested_subject,phone_no;
    Button updateBtn;
    Spinner genderSelect;
    LinearLayout checkboxcontainer;
    String genderSpinnerItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        db=new DatabaseHelper(this);

        /*Spinner*/
        genderSelect= (Spinner) findViewById(R.id.genderSpinner);
        /**/
        addClasses= (TextView) findViewById(R.id.addClassesTV);
        email= (TextView) findViewById(R.id.email);
        updateBtn= (Button) findViewById(R.id.update_profile);
        name= (EditText) findViewById(R.id.nameET);
        qualification= (EditText) findViewById(R.id.qualificationET);
        interested_subject= (EditText) findViewById(R.id.interested_subjectET);
        phone_no= (EditText) findViewById(R.id.phone_noET);

        checkboxcontainer= (LinearLayout) findViewById(R.id.checkBoxContainer);


        Bundle b =getIntent().getExtras();

        if(b!=null)
        {
            emailText =b.getString("email");
            email.setText(emailText);
        }

    }

    public void addClass(View view) {
        chocieCollection=new ArrayList<>();
        for(int i=0;i<checkboxcontainer.getChildCount();i++){
            View unknownview=checkboxcontainer.getChildAt(i);
            if(unknownview instanceof CheckBox){
                CheckBox checkBox=(CheckBox)unknownview;
                if(checkBox.isChecked()){
                    chocieCollection.add(checkBox.getText().toString());
                }
            }

        }
        classCollection = "";

        for (String s : chocieCollection)
        {
            classCollection += s + "\t";
        }
        Toast.makeText(this,classCollection,Toast.LENGTH_SHORT).show();
    }

    public void UpdateData() {

        boolean isUpdate = db.updateData(emailText,name.getText().toString(),
                genderSpinnerItem,
                qualification.getText().toString(),
                interested_subject.getText().toString(),
                classCollection,
                phone_no.getText().toString());
        if(isUpdate == true)
            Toast.makeText(EditProfile.this,"Data Update",Toast.LENGTH_LONG).show();
        else
            Toast.makeText(EditProfile.this,"Data not Updated",Toast.LENGTH_LONG).show();
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        genderSpinnerItem=parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(),genderSpinnerItem,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void gotoProfile(View view) {
        Intent profile_page=new Intent(EditProfile.this,ProfileTeacher.class);
        profile_page.putExtra("email",email.getText());
        startActivity(profile_page);
    }

    public void update(View view) {
        UpdateData();
    }
    public void onBackPressed() {

    }
}
